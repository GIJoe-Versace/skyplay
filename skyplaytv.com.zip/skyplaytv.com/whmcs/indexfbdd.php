<?xml version="1.0" encoding="utf-8"?>
            <rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
                <channel>
                    <atom:link href="https://skyplaytv.com/whmcs/index.php?rp=/announcements/rss" rel="self" type="application/rss+xml" />
                    <title><![CDATA[Skyplay]]></title>
                    <description><![CDATA[Skyplay Сповіщення RSS]]></description>
                    <link>https://skyplaytv.com/whmcs/index.php?rp=/announcements</link>
                    
<item>
    <title><![CDATA[Thank you for choosing WHMCS!]]></title>
    <link>https://skyplaytv.com/whmcs/index.php?rp=/announcements/1</link>
    <guid>https://skyplaytv.com/whmcs/index.php?rp=/announcements/1</guid>
    <pubDate>Пт, 27 черв. 2025 07:54:25 +0000</pubDate>
    <description><![CDATA[<p>Welcome to <a title="WHMCS" href="http://whmcs.com" target="_blank">WHMCS</a>!
 You have made a great choice and we want to help you get up and running as
 quickly as possible.</p>
<p>This is a sample announcement. Announcements are a great way to keep your
 customers informed about news and special offers. You can edit or delete this
 announcement by logging into the admin area and navigating to <em>Support &gt;
 Announcements</em>.</p>
<p>If at any point you get stuck, our support team is available 24x7 to
 assist you. Simply visit <a title="www.whmcs.com/support"
 href="https://www.whmcs.com/support" target="_blank">www.whmcs.com/support</a>
 to request assistance.</p>]]></description>
</item>
                </channel>
            </rss>